self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a6501650f1a291bfa7c3f5905e17386c",
    "url": "/index.html"
  },
  {
    "revision": "da6a5be730da482d9809",
    "url": "/static/js/2.2ee7352d.chunk.js"
  },
  {
    "revision": "89b0379e7bcda1a468d8b0343aeb4e53",
    "url": "/static/js/2.2ee7352d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fe49162b4cd047824156",
    "url": "/static/js/main.ab7782d8.chunk.js"
  },
  {
    "revision": "98e7f58ebc01c9a6852c",
    "url": "/static/js/runtime-main.11e8592c.js"
  },
  {
    "revision": "402b025f443a0461f17c427116c9d86d",
    "url": "/static/media/logo_black.402b025f.svg"
  },
  {
    "revision": "6644459c78aee17e35f68a0547603971",
    "url": "/static/media/logo_blue.6644459c.svg"
  }
]);