self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7feaec06b4cccc0ee49380ac3bca53ae",
    "url": "/index.html"
  },
  {
    "revision": "b348579c7f4d9e46d20e",
    "url": "/static/js/2.8fdbb80e.chunk.js"
  },
  {
    "revision": "89b0379e7bcda1a468d8b0343aeb4e53",
    "url": "/static/js/2.8fdbb80e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2ab9e9e9471039f52aee",
    "url": "/static/js/main.a872a858.chunk.js"
  },
  {
    "revision": "98e7f58ebc01c9a6852c",
    "url": "/static/js/runtime-main.11e8592c.js"
  },
  {
    "revision": "402b025f443a0461f17c427116c9d86d",
    "url": "/static/media/logo_black.402b025f.svg"
  },
  {
    "revision": "6644459c78aee17e35f68a0547603971",
    "url": "/static/media/logo_blue.6644459c.svg"
  }
]);