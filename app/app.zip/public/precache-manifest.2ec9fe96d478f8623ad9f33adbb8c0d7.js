self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "becf20f21ce194b0b9b16a590a0d6ab5",
    "url": "/index.html"
  },
  {
    "revision": "586d07c2b7b3e34ced70",
    "url": "/static/js/2.5b88a96b.chunk.js"
  },
  {
    "revision": "89b0379e7bcda1a468d8b0343aeb4e53",
    "url": "/static/js/2.5b88a96b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fe73c610b5bca5738608",
    "url": "/static/js/main.22a68592.chunk.js"
  },
  {
    "revision": "98e7f58ebc01c9a6852c",
    "url": "/static/js/runtime-main.11e8592c.js"
  },
  {
    "revision": "402b025f443a0461f17c427116c9d86d",
    "url": "/static/media/logo_black.402b025f.svg"
  },
  {
    "revision": "6644459c78aee17e35f68a0547603971",
    "url": "/static/media/logo_blue.6644459c.svg"
  }
]);