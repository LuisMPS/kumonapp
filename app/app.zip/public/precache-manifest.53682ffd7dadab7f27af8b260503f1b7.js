self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e88a3abc4de860666aebafcff907584c",
    "url": "/index.html"
  },
  {
    "revision": "d8f33ba3b3e34767bc39",
    "url": "/static/js/2.1340fc4b.chunk.js"
  },
  {
    "revision": "89b0379e7bcda1a468d8b0343aeb4e53",
    "url": "/static/js/2.1340fc4b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "87e59c03a9023f40d211",
    "url": "/static/js/main.52ed0762.chunk.js"
  },
  {
    "revision": "98e7f58ebc01c9a6852c",
    "url": "/static/js/runtime-main.11e8592c.js"
  },
  {
    "revision": "402b025f443a0461f17c427116c9d86d",
    "url": "/static/media/logo_black.402b025f.svg"
  },
  {
    "revision": "6644459c78aee17e35f68a0547603971",
    "url": "/static/media/logo_blue.6644459c.svg"
  }
]);